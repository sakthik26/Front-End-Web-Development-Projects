var app = angular.module('myApp',[]);

app.controller('DynamicForm',function($scope){
   
	$scope.formcontrols = [
	{type:"text", name:"name" ,label:"Name", required:true, data:"",model:"name1" },
	{type:"select", name:"dropdown", label:"Select", options:[{id:1, name:"option1"},{id:2, name:"option2"},{id:3,name:"option3"}], required:true , data:"",model:"select1"},
    {type:"text", name:"name2" ,label:"Name", required:true, data:"",model:"name2"},
    {type:"select", name:"dropdown2", label:"Select", options:[{id:1, name:"option1"},{id:2, name:"option2"},{id:3,name:"option3"}], required:true , data:"",model:"select2"}
    ]	
   
    $scope.form={};
    $scope.form.name="hello";
    $scope.form.select = "sdfsf"
 

    $scope.getFormValues = function(){
    	console.log('In form values');
    	$scope.form={};
    	$scope.form.name="its me";
        $scope.form.select = "sdfsf"
        alert("form submitted");

    }

 /* $scope.formcontrols.forEach(function(data){

        if(data.type === "text"){
         $scope.$broadcast('emittext',data); 
        }
        else if(data.type === "select"){
         $scope.$broadcast('emittext',data); 
        }
        else if(data.type === "select"){
         $scope.$broadcast('emittext',[1,2,3]);
        }
    })*/
    /*alert(JSON.stringify($scope.controlTypeArray));*/
    /* $scope.$on('returntext',function(event,data){
        
          $scope.controlTypeArray.push(data);
         })*/

    /* $scope.ShowValue= function(){
    
    $scope.$broadcast('emittext',[1,2,3]);}*/

    $scope.ShowValue= function(){    
    $scope.formcontrols.forEach(function(data){
    $scope.$broadcast('emittext',data);
    })
    }

    $scope.$on('returntext',function(event,data){
    	$scope.controlTypeArray.push(data);

    })

})
	
app.directive('textTemplate', function(){
  
  return {
     restrict : 'E',
     templateUrl : 'text-template.html'
  };

  })

app.directive('selectTemplate',function(){

  return{
  	restrict: 'E',
  	templateUrl: 'select-template.html'
  };


})
app.controller('textController',function($scope){

	$scope.$on('emittext',function(event,data){
		$scope.values = data;

	$scope.$emit('returntext',$scope.values);		
	})
})

app.controller('selectController',function($scope){

	$scope.$on('emitselect',function(event,data){

	})
})