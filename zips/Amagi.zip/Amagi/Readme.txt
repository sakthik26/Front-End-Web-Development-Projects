-------- README ----------


1) Aired At Time From JSON is taken here as the UTC time, thereby calculating the user local time by adding/subtracting the offset time from UTC.
2) Date sort Available on the  right corner
3) Time sort for individual blocks.
4) Search provided for Date and Other Json values.
5) Kindly check out my other front end development projects on codepen
 http://codepen.io/sakthik26/